user_num = int(input("Enter integer:\n"))

print(f"You entered: {user_num}")
print(f"{user_num} squared is {user_num ** 2}")
print(f"And {user_num} cubed is {user_num ** 3} !!")

user_num2 = int(input("Enter another integer:\n"))

print(f"{user_num} + {user_num2} is {user_num + user_num2}")
print(f"{user_num} * {user_num2} is {user_num * user_num2}")

